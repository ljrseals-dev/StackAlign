#!/usr/bin/env bash
# SPDX-License-Identifier: MIT
# Author: Lewis James Seals Jr.
# tests/test_verify.sh -- release verification with REAL gpg/gpgv and throwaway keys.
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if ! command -v gpg >/dev/null 2>&1 || ! command -v gpgv >/dev/null 2>&1; then
    echo "NOT RUN: gpg/gpgv not installed (install gnupg2 to run this suite)"; exit 0
fi
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
export GNUPGHOME="$T/gpg"; mkdir -m 700 "$GNUPGHOME"
fail=0
check() { if [ "$2" = "$3" ]; then echo "ok   $1"; else echo "FAIL $1 (got '$2' want '$3')"; fail=1; fi; }

genkey() { gpg --batch --quiet --pinentry-mode loopback --passphrase '' --quick-generate-key "$1" ed25519 sign never 2>/dev/null; }
fprof() { gpg --list-keys --with-colons "$1" 2>/dev/null | awk -F: '/^fpr/{print $10; exit}'; }
genkey "StackAlign Test <rel@test.invalid>"; genkey "Attacker <evil@test.invalid>"
FPR="$(fprof rel@test.invalid)"; EVIL="$(fprof evil@test.invalid)"
gpg --export rel@test.invalid > "$T/ring-good.gpg" 2>/dev/null
cat "$T/ring-good.gpg" > "$T/ring-both.gpg"; gpg --export evil@test.invalid >> "$T/ring-both.gpg" 2>/dev/null
[ -n "$FPR" ] && [ -n "$EVIL" ] && [ "$FPR" != "$EVIL" ]; check "throwaway keys created" "$?" 0
[ -n "$FPR" ] && [ -n "$EVIL" ] || { echo "SETUP FAILED: could not generate test keys" >&2; exit 1; }

NAME="stackalign-0.1.0.tar.gz"
# mkrel <dir> <expires-line-or-empty> <signer-fingerprint>
mkrel() {
    local d=$1 exp=$2 who=$3
    rm -rf "$d"; mkdir -p "$d"
    printf 'release payload\n' > "$d/$NAME"
    { [ -n "$exp" ] && echo "# expires: $exp"; echo "$(sha256sum "$d/$NAME" | awk '{print $1}')  $NAME"; } > "$d/SHA256SUMS"
    gpg --batch --yes --quiet --pinentry-mode loopback --passphrase '' --local-user "$who" \
        --detach-sign --output "$d/SHA256SUMS.sig" "$d/SHA256SUMS" 2>/dev/null \
        && [ -s "$d/SHA256SUMS.sig" ] || { echo "SETUP FAILED: signing failed in mkrel ($d)" >&2; exit 1; }
}
verify() { # dir ring fpr
    ( . "$ROOT/lib/verify.sh"; sa_verify_artifact "$1/$NAME" "$1/SHA256SUMS" "$1/SHA256SUMS.sig" "$2" "$3" ) >"$T/out" 2>"$T/err"
}
FUT="2099-01-01T00:00:00Z"; PAST="2000-01-01T00:00:00Z"

mkrel "$T/r1" "$FUT" "$FPR"; verify "$T/r1" "$T/ring-good.gpg" "$FPR"; check "valid release => 0" "$?" 0
check "prints the verified path" "$(cat "$T/out")" "$T/r1/$NAME"
verify "$T/r1" "$T/ring-good.gpg" "$(echo "$FPR" | tr 'A-F' 'a-f')"; check "lowercase pin accepted" "$?" 0

mkrel "$T/r2" "$FUT" "$FPR"; echo tamper >> "$T/r2/$NAME"
verify "$T/r2" "$T/ring-good.gpg" "$FPR"; check "tampered artifact => 5" "$?" 5

mkrel "$T/r3" "$FUT" "$FPR"; echo "# extra line" >> "$T/r3/SHA256SUMS"
verify "$T/r3" "$T/ring-good.gpg" "$FPR"; check "tampered SHA256SUMS (bad signature) => 4" "$?" 4

mkrel "$T/r4" "$FUT" "$EVIL"
verify "$T/r4" "$T/ring-good.gpg" "$FPR"; check "attacker-signed, key not in keyring => 4" "$?" 4
verify "$T/r4" "$T/ring-both.gpg" "$FPR"; check "attacker key in keyring but not pinned => 4" "$?" 4
mkrel "$T/r5" "$FUT" "$FPR"
verify "$T/r5" "$T/ring-both.gpg" "$EVIL"; check "wrong pinned fingerprint => 4" "$?" 4
verify "$T/r5" "$T/ring-good.gpg" "NOTAFINGERPRINT"; check "malformed pin => 64" "$?" 64

mkrel "$T/r6" "$PAST" "$FPR"; verify "$T/r6" "$T/ring-good.gpg" "$FPR"; check "expired metadata => 6" "$?" 6
mkrel "$T/r7" "" "$FPR";      verify "$T/r7" "$T/ring-good.gpg" "$FPR"; check "no expiry line => 6" "$?" 6
mkrel "$T/r8" "garbage" "$FPR"; verify "$T/r8" "$T/ring-good.gpg" "$FPR"; check "malformed expiry => 6" "$?" 6

resign() {
    gpg --batch --yes --quiet --pinentry-mode loopback --passphrase '' --local-user "$FPR" \
        --detach-sign --output "$1/SHA256SUMS.sig" "$1/SHA256SUMS" 2>/dev/null \
        && [ -s "$1/SHA256SUMS.sig" ] || { echo "SETUP FAILED: signing failed in resign ($1)" >&2; exit 1; }
}
mkrel "$T/e1" "$FUT" "$FPR"; { echo "# expires: $FUT"; echo "# expires: $FUT"; echo "$(sha256sum "$T/e1/$NAME" | awk '{print $1}')  $NAME"; } > "$T/e1/SHA256SUMS"; resign "$T/e1"
verify "$T/e1" "$T/ring-good.gpg" "$FPR"; check "two expiry lines => 6" "$?" 6
mkrel "$T/e2" "2099-02-31T00:00:00Z" "$FPR"; verify "$T/e2" "$T/ring-good.gpg" "$FPR"; check "impossible date (Feb 31) => 6" "$?" 6
mkrel "$T/e3" "2099-13-01T00:00:00Z" "$FPR"; verify "$T/e3" "$T/ring-good.gpg" "$FPR"; check "impossible month (13) => 6" "$?" 6
mkrel "$T/e4" "2099-01-01T25:00:00Z" "$FPR"; verify "$T/e4" "$T/ring-good.gpg" "$FPR"; check "impossible hour (25) => 6" "$?" 6
mkrel "$T/e5" "$FUT trailing" "$FPR"; verify "$T/e5" "$T/ring-good.gpg" "$FPR"; check "trailing text after expiry => 6" "$?" 6
mkrel "$T/e6" "$FUT" "$FPR"; { echo "# expires: $PAST"; echo "# expires: $FUT"; echo "$(sha256sum "$T/e6/$NAME" | awk '{print $1}')  $NAME"; } > "$T/e6/SHA256SUMS"; resign "$T/e6"
verify "$T/e6" "$T/ring-good.gpg" "$FPR"; check "expired + future lines (first wins attack) => 6" "$?" 6
mkrel "$T/e7" "2099-02-28T23:59:59Z" "$FPR"; verify "$T/e7" "$T/ring-good.gpg" "$FPR"; check "valid boundary date accepted" "$?" 0

mkrel "$T/r9" "$FUT" "$FPR"; { echo "# expires: $FUT"; echo "$(sha256sum "$T/r9/$NAME" | awk '{print $1}')  other.tar.gz"; } > "$T/r9/SHA256SUMS"
resign "$T/r9"
verify "$T/r9" "$T/ring-good.gpg" "$FPR"; check "artifact not listed => 5" "$?" 5

mkrel "$T/r10" "$FUT" "$FPR"; H="$(sha256sum "$T/r10/$NAME" | awk '{print $1}')"
{ echo "# expires: $FUT"; echo "$H  $NAME"; echo "$H  $NAME"; } > "$T/r10/SHA256SUMS"
resign "$T/r10"
verify "$T/r10" "$T/ring-good.gpg" "$FPR"; check "duplicate entries => 5" "$?" 5

mkrel "$T/r11" "$FUT" "$FPR"; : > "$T/r11/SHA256SUMS.sig"
verify "$T/r11" "$T/ring-good.gpg" "$FPR"; check "empty signature file => 4" "$?" 4
mkrel "$T/r12" "$FUT" "$FPR"; rm "$T/r12/SHA256SUMS.sig"
verify "$T/r12" "$T/ring-good.gpg" "$FPR"; check "missing signature file => 64" "$?" 64
mkrel "$T/r13" "$FUT" "$FPR"; mv "$T/r13/$NAME" "$T/r13/bad name.tgz"; NAME_SAVE=$NAME; NAME="bad name.tgz"
verify "$T/r13" "$T/ring-good.gpg" "$FPR"; check "unsafe artifact name => 64" "$?" 64; NAME=$NAME_SAVE

# --- fake gpgv: status-line handling (revoked/expired keys, duplicate or missing VALIDSIG) ---
mkdir -p "$T/fake"; mkrel "$T/r14" "$FUT" "$FPR"
fakegpgv() { printf '#!/usr/bin/env bash\ncat <<STATUS\n%s\nSTATUS\nexit 0\n' "$1" > "$T/fake/gpgv"; chmod +x "$T/fake/gpgv"; }
V="[GNUPG:] VALIDSIG $FPR 2026-01-01 1 0 4 0 22 10 00 $FPR"
G="[GNUPG:] GOODSIG ABCD StackAlign Test"
fakegpgv "$G
$V"; ( PATH="$T/fake:$PATH"; verify "$T/r14" "$T/ring-good.gpg" "$FPR" ); check "fake gpgv: good status => 0" "$?" 0
fakegpgv "[GNUPG:] REVKEYSIG ABCD x
$G
$V"; ( PATH="$T/fake:$PATH"; verify "$T/r14" "$T/ring-good.gpg" "$FPR" ); check "revoked key => 4" "$?" 4
fakegpgv "[GNUPG:] EXPKEYSIG ABCD x
$G
$V"; ( PATH="$T/fake:$PATH"; verify "$T/r14" "$T/ring-good.gpg" "$FPR" ); check "expired key => 4" "$?" 4
fakegpgv "$G"; ( PATH="$T/fake:$PATH"; verify "$T/r14" "$T/ring-good.gpg" "$FPR" ); check "GOODSIG without VALIDSIG => 4" "$?" 4
fakegpgv "$G
$V
$V"; ( PATH="$T/fake:$PATH"; verify "$T/r14" "$T/ring-good.gpg" "$FPR" ); check "two VALIDSIG lines => 4" "$?" 4
fakegpgv "$G
[GNUPG:] VALIDSIG $EVIL 2026-01-01 1 0 4 0 22 10 00 $FPR"; ( PATH="$T/fake:$PATH"; verify "$T/r14" "$T/ring-good.gpg" "$FPR" ); check "signing subkey is fine when PRIMARY matches pin" "$?" 0
fakegpgv "$G
[GNUPG:] VALIDSIG $FPR 2026-01-01 1 0 4 0 22 10 00 $EVIL"; ( PATH="$T/fake:$PATH"; verify "$T/r14" "$T/ring-good.gpg" "$FPR" ); check "primary fingerprint differs from pin => 4" "$?" 4

# --- both VALIDSIG formats, against REAL keys -------------------------------------------
# status <dir> <ring>: the raw VALIDSIG line gpgv emits for that release bundle
status() { local h; h="$(mktemp -d)"; gpgv --homedir "$h" --status-fd 1 --keyring "$2" -- "$1/SHA256SUMS.sig" "$1/SHA256SUMS" 2>/dev/null | grep '^\[GNUPG:\] VALIDSIG '; rm -rf "$h"; }

# (1) primary-only key: no subkeys exist, the PRIMARY signs.
[ "$(gpg --list-keys --with-colons rel@test.invalid 2>/dev/null | grep -c '^sub')" -eq 0 ]; check "test key is primary-only (no subkeys)" "$?" 0
mkrel "$T/p1" "$FUT" "$FPR"; L="$(status "$T/p1" "$T/ring-good.gpg")"
F3="$(awk '{print toupper($3)}' <<<"$L")"; F12="$(awk '{print toupper($12)}' <<<"$L")"
check "primary-key signature: field 3 is the primary fingerprint" "$F3" "$FPR"
if [ -n "$F12" ]; then check "primary-key signature: field 12 (when present) equals field 3" "$F12" "$F3"
else echo "note  this GnuPG omits field 12 for primary-key signatures (fallback path is live)"; fi
verify "$T/p1" "$T/ring-good.gpg" "$FPR"; check "primary-only key verifies against its own pin" "$?" 0

# (2) key with a signing SUBKEY: the subkey signs, the pin is the PRIMARY.
gpg --batch --quiet --pinentry-mode loopback --passphrase '' --quick-generate-key "Sub Test <sub@test.invalid>" ed25519 cert never 2>/dev/null
SPRIM="$(fprof sub@test.invalid)"
gpg --batch --quiet --pinentry-mode loopback --passphrase '' --quick-add-key "$SPRIM" ed25519 sign never 2>/dev/null
SSUB="$(gpg --list-keys --with-colons --with-subkey-fingerprints sub@test.invalid 2>/dev/null | awk -F: '/^sub/{s=1;next} s&&/^fpr/{print $10; exit}')"
gpg --export sub@test.invalid > "$T/ring-sub.gpg" 2>/dev/null
{ [ -n "$SPRIM" ] && [ -n "$SSUB" ] && [ "$SPRIM" != "$SSUB" ]; }; check "subkey test key has distinct primary and signing subkey" "$?" 0
mkrel "$T/s1" "$FUT" "${SSUB}!"
L="$(status "$T/s1" "$T/ring-sub.gpg")"
F3="$(awk '{print toupper($3)}' <<<"$L")"; F12="$(awk '{print toupper($12)}' <<<"$L")"
check "subkey signature: field 3 is the SUBKEY fingerprint" "$F3" "$SSUB"
check "subkey signature: field 12 is the PRIMARY fingerprint" "$F12" "$SPRIM"
verify "$T/s1" "$T/ring-sub.gpg" "$SPRIM"; check "subkey-signed release verifies against the PRIMARY pin" "$?" 0
verify "$T/s1" "$T/ring-sub.gpg" "$SSUB";  check "pinning the SUBKEY fingerprint is refused" "$?" 4

# (3) field 12 ABSENT (format variant): falls back to field 3; fake gpgv.
G2="[GNUPG:] GOODSIG ABCD StackAlign Test"
fakegpgv "$G2
[GNUPG:] VALIDSIG $FPR 2026-01-01 1 0 4 0 22 10 00"; ( PATH="$T/fake:$PATH"; verify "$T/r14" "$T/ring-good.gpg" "$FPR" ); check "no field 12: fingerprint (field 3) equals pin => 0" "$?" 0
fakegpgv "$G2
[GNUPG:] VALIDSIG $EVIL 2026-01-01 1 0 4 0 22 10 00"; ( PATH="$T/fake:$PATH"; verify "$T/r14" "$T/ring-good.gpg" "$FPR" ); check "no field 12: field 3 differs from pin => 4" "$?" 4
fakegpgv "$G2
[GNUPG:] VALIDSIG $SSUB 2026-01-01 1 0 4 0 22 10 00"; ( PATH="$T/fake:$PATH"; verify "$T/r14" "$T/ring-sub.gpg" "$SPRIM" ); check "no field 12 + subkey fingerprint, primary pinned => 4 (fails closed)" "$?" 4

# --- environment failures must fail closed / fail fast ---
mkdir -p "$T/failgpg" "$T/fakedate" "$T/nogpgv"
printf '#!/usr/bin/env bash\nexit 1\n' > "$T/failgpg/gpg"; chmod +x "$T/failgpg/gpg"
( PATH="$T/failgpg:$PATH"; mkrel "$T/s9" "$FUT" "$FPR" ) >/dev/null 2>"$T/err"; rc=$?
check "mkrel: signing failure is a SETUP failure (exit 1)" "$rc" 1
grep -q 'SETUP FAILED: signing failed in mkrel' "$T/err"; check "mkrel: setup failure is reported as such" "$?" 0
mkrel "$T/s10" "$FUT" "$FPR"
( PATH="$T/failgpg:$PATH"; resign "$T/s10" ) >/dev/null 2>"$T/err"; rc=$?
check "resign: signing failure is a SETUP failure (exit 1)" "$rc" 1
grep -q 'SETUP FAILED: signing failed in resign' "$T/err"; check "resign: setup failure is reported as such" "$?" 0

# second `date` call (the clock read) fails while `date -d` works: must NOT accept the release
real_date="$(command -v date)"
printf '#!/usr/bin/env bash\ncase "$*" in *"-d "*) exec %s "$@" ;; esac\nexit 1\n' "$real_date" > "$T/fakedate/date"; chmod +x "$T/fakedate/date"
mkrel "$T/c1" "$FUT" "$FPR"
( PATH="$T/fakedate:$PATH"; verify "$T/c1" "$T/ring-good.gpg" "$FPR" ); check "clock read fails => refuse (6), never accept" "$?" 6

# gpgv missing: explicit diagnostic, still non-zero
for f in /usr/bin/*; do [ "${f##*/}" = gpgv ] || ln -sf "$f" "$T/nogpgv/${f##*/}" 2>/dev/null; done
( PATH="$T/nogpgv"; verify "$T/c1" "$T/ring-good.gpg" "$FPR" ); check "gpgv missing => 4" "$?" 4
grep -q 'gpgv is not installed' "$T/err"; check "gpgv missing: accurate diagnostic" "$?" 0

# --- anti-downgrade ---
( . "$ROOT/lib/verify.sh"
  sa_verify_not_downgrade 1.2.0 1.3.0 2>/dev/null; echo "up $?"
  sa_verify_not_downgrade 1.2.0 1.2.0 2>/dev/null; echo "same $?"
  sa_verify_not_downgrade 1.10.0 1.9.0 2>/dev/null; echo "down $?"
  SA_ALLOW_DOWNGRADE=1 sa_verify_not_downgrade 1.10.0 1.9.0 2>/dev/null; echo "envoverride $?"
  sa_verify_not_downgrade 1.2.0 1.2.0-rc1 2>/dev/null; echo "badver $?" ) > "$T/dg"
check "upgrade ok" "$(grep '^up ' "$T/dg")" "up 0"
check "same version ok" "$(grep '^same ' "$T/dg")" "same 0"
check "downgrade refused (1.10 -> 1.9, numeric not lexical)" "$(grep '^down ' "$T/dg")" "down 7"
check "SA_ALLOW_DOWNGRADE=1 is ignored (no env override) => 7" "$(grep '^envoverride ' "$T/dg")" "envoverride 7"
check "pre-release tags rejected" "$(grep '^badver ' "$T/dg")" "badver 64"
exit "$fail"
