#!/usr/bin/env bash
# SPDX-License-Identifier: MIT
# Author: Lewis James Seals Jr.
# lib/verify.sh -- verify a downloaded StackAlign release artifact. Offline, fail closed.
#
# Chain of trust: pinned fingerprint + LOCAL keyring --> detached signature over
# SHA256SUMS --> expiry line inside the signed file --> sha256 of the artifact.
# The keyring and fingerprint must come from somewhere other than the download
# (installed with the tool, or typed in by the operator). Never from the bundle.
#
# Return codes: 0 ok | 4 signature/key/fingerprint failure | 5 checksum failure
#               6 metadata expired or missing | 7 downgrade refused | 64 usage
#
# ASSUMPTIONS to verify on real hosts: `gpgv --keyring <binary export>` accepts a
# keyring made with `gpg --export`; the VALIDSIG status line carries the primary-key
# fingerprint in field 12 when GnuPG reports one (tests/test_verify.sh checks both the
# primary-key and subkey formats against real keys, and the field-12-absent fallback with a fake).
. "$(dirname "${BASH_SOURCE[0]}")/common.sh"

# _sa_verify_sig <sums> <sig> <keyring> <fingerprint>
_sa_verify_sig() {
    local sums=$1 sig=$2 ring=$3 fpr=${4^^} out home prim n
    [[ $fpr =~ ^[0-9A-F]{40}$ ]] || { echo "verify: pinned fingerprint must be 40 hex digits" >&2; return 64; }
    home="$(mktemp -d)" || return 4
    out="$(gpgv --homedir "$home" --status-fd 1 --keyring "$ring" -- "$sig" "$sums" 2>/dev/null)" || { rm -rf "$home"; return 4; }
    rm -rf "$home"
    grep -q '^\[GNUPG:\] GOODSIG ' <<<"$out" || return 4
    if grep -Eq '^\[GNUPG:\] (EXPKEYSIG|REVKEYSIG|EXPSIG|BADSIG|ERRSIG|NO_PUBKEY)' <<<"$out"; then return 4; fi
    n="$(grep -c '^\[GNUPG:\] VALIDSIG ' <<<"$out")"
    [ "$n" -eq 1 ] || return 4
    # Field 12 = primary-key fingerprint (present when GnuPG reports it, always for subkey
    # signatures). If it is absent, the signing key is the primary, so field 3 is used.
    # A subkey signature without field 12 would show the subkey fingerprint here and fail the pin.
    prim="$(awk '$1=="[GNUPG:]" && $2=="VALIDSIG" {print toupper(($12 != "") ? $12 : $3)}' <<<"$out")"
    [ "$prim" = "$fpr" ] || return 4
}

# The signed SHA256SUMS must carry EXACTLY ONE line `# expires: YYYY-MM-DDTHH:MM:SSZ` (UTC),
# a real calendar date/time (2099-02-31 is rejected), in the future. Anything else => 6.
_sa_verify_expiry() {
    local n line exp norm now
    n="$(grep -c '^# expires:' "$1")"
    [ "$n" -eq 1 ] || return 6
    line="$(grep '^# expires:' "$1")"
    [[ $line =~ ^#\ expires:\ ([0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z)$ ]] || return 6
    exp="${BASH_REMATCH[1]}"
    norm="$(date -u -d "$exp" +%Y-%m-%dT%H:%M:%SZ 2>/dev/null)" || return 6
    [ "$norm" = "$exp" ] || return 6
    now="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    [ -n "$now" ] || return 6          # fail closed: an empty clock string would sort before any date
    [[ $now < $exp ]] || return 6
}

# Exactly one entry for the artifact name, and its hash must match.
_sa_verify_hash() {
    local sums=$1 name=$2 file=$3 n want got
    n="$(awk -v f="$name" '$2==f {c++} END{print c+0}' "$sums")"
    [ "$n" -eq 1 ] || return 5
    want="$(awk -v f="$name" '$2==f {print $1}' "$sums")"
    [[ $want =~ ^[0-9a-f]{64}$ ]] || return 5
    got="$(sha256sum -- "$file" | awk '{print $1}')"
    [ "$want" = "$got" ] || return 5
}

# sa_verify_artifact <artifact> <SHA256SUMS> <SHA256SUMS.sig> <keyring> <fingerprint>
sa_verify_artifact() {
    [ $# -eq 5 ] || { echo "usage: sa_verify_artifact artifact sums sig keyring fingerprint" >&2; return 64; }
    local art=$1 sums=$2 sig=$3 ring=$4 fpr=$5 name rc=0
    local f
    for f in "$art" "$sums" "$sig" "$ring"; do
        [ -f "$f" ] || { echo "verify: missing file: $f" >&2; return 64; }
    done
    command -v gpgv >/dev/null 2>&1 || { echo "verify: gpgv is not installed; cannot verify (install gnupg2)" >&2; return 4; }
    name="${art##*/}"
    [[ $name =~ ^[A-Za-z0-9][A-Za-z0-9._+-]*$ ]] || { echo "verify: unsafe artifact name" >&2; return 64; }

    _sa_verify_sig "$sums" "$sig" "$ring" "$fpr" || { rc=$?; [ $rc -eq 64 ] || echo "verify: signature/key check failed" >&2; return $rc; }
    _sa_verify_expiry "$sums" || { echo "verify: release metadata expired or has no expiry" >&2; return 6; }
    _sa_verify_hash "$sums" "$name" "$art" || { echo "verify: checksum mismatch or entry missing/duplicated for $name" >&2; return 5; }
    printf '%s\n' "$art"
}

# sa_verify_not_downgrade <current> <candidate>   plain dotted numbers only (no pre-release tags)
# There is deliberately NO environment-variable override: anything that can set an env var
# must not be able to authorise a downgrade. A deliberate rollback uses the local snapshot
# (see docs/RELEASE-TRUST.md), not a re-download of an older release.
sa_verify_not_downgrade() {
    local cur=${1:-} cand=${2:-} newest
    [[ $cur =~ ^[0-9]+(\.[0-9]+){0,3}$ && $cand =~ ^[0-9]+(\.[0-9]+){0,3}$ ]] || { echo "verify: bad version string" >&2; return 64; }
    newest="$(printf '%s\n%s\n' "$cur" "$cand" | sort -V | tail -n 1)"
    if [ "$newest" = "$cand" ]; then return 0; fi
    echo "verify: refusing downgrade $cur -> $cand" >&2
    return 7
}
