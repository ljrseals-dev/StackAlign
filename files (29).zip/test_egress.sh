#!/usr/bin/env bash
# SPDX-License-Identifier: MIT
# Author: Lewis James Seals Jr.
# tests/test_egress.sh -- these tests check what the module EMITS and the ORDER/EXIT CODES of
# its actions against fake tools. They do not prove behaviour on a real kernel; see the header
# of lib/egress.sh for what still needs a throwaway-VM test.
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
mkdir -p "$T/bin"; : > "$T/calls"
export CALLS="$T/calls" PATH="$T/bin:$PATH"
fail=0
check() { if [ "$2" = "$3" ]; then echo "ok   $1"; else echo "FAIL $1 (got '$2' want '$3')"; fail=1; fi; }
mkfake() { printf "%s\n" "#!/usr/bin/env bash" "$2" > "$T/bin/$1"; chmod +x "$T/bin/$1"; }
mkfake nft 'echo "nft $*" >> "$CALLS"; case "$1" in -c) exit "${FAKE_NFT_CHECK_RC:-0}";; -f) exit "${FAKE_NFT_LOAD_RC:-0}";; list) exit "${FAKE_NFT_LIST_RC:-0}";; delete) exit "${FAKE_NFT_DELETE_RC:-0}";; esac; exit 0'
mkfake systemd-run 'echo "systemd-run $*" >> "$CALLS"; exit "${FAKE_SDRUN_RC:-0}"'
mkfake systemctl 'echo "systemctl $*" >> "$CALLS"; case "$1" in is-active) [ "${FAKE_TIMER_ACTIVE:-0}" = 1 ] && exit 0; exit 3;; stop) exit "${FAKE_STOP_RC:-0}";; esac; exit 0'
mkfake logger 'echo "logger $*" >> "$CALLS"'
mkfake getent 'if [ "$1" = ahostsv4 ]; then case "$2" in updates.example.com) echo "203.0.113.10 STREAM $2"; echo "203.0.113.11 STREAM $2"; echo "203.0.113.10 DGRAM $2" ;; esac; fi; exit 0'
mkfake ip 'cat "$FAKE_NEIGH"'
. "$ROOT/lib/egress.sh"
has() { case "$R" in *"$1"*) return 0 ;; esac; return 1; }
calls_has() { grep -q -- "$1" "$CALLS"; }
line_of() { grep -n -- "$1" "$CALLS" | head -1 | cut -d: -f1; }

cat > "$T/allow" <<'A'
# studio allowlist
203.0.113.0/24      tcp 443   # inline comment must be ignored

updates.example.com tcp 443
2001:db8::1         udp 123
nowhere.example.net tcp 443
A
R="$(sa_egress_render "$T/allow" "9.9.9.9,2620:fe::fe" "192.168.1.0/24,fd00:1::/64" 2>"$T/err")"; check "render ok" "$?" 0
has "policy drop"; check "output chain default-drop" "$?" 0
has 'oif "lo" accept'; check "loopback allowed" "$?" 0
has "ct state established,related accept"; check "replies allowed" "$?" 0
has "ip daddr 9.9.9.9 udp dport 53 accept"; check "DNS only to named resolver (v4)" "$?" 0
has "ip6 daddr 2620:fe::fe tcp dport 53 accept"; check "DNS only to named resolver (v6)" "$?" 0
case "$R" in *$'\n'"    udp dport 53 accept"*|*$'\n'"    tcp dport 53 accept"*) check "no unconditional DNS rule" 1 0 ;; *) check "no unconditional DNS rule" 0 0 ;; esac
has "ip daddr 192.168.1.0/24 accept"; check "IPv4 LAN range uses ip daddr" "$?" 0
has "ip6 daddr fd00:1::/64 accept"; check "IPv6 LAN range uses ip6 daddr" "$?" 0
case "$R" in *"ip daddr fd00:1::/64"*) check "IPv6 LAN never emitted as ip daddr" 1 0 ;; *) check "IPv6 LAN never emitted as ip daddr" 0 0 ;; esac
has "ip daddr 203.0.113.0/24 tcp dport 443 accept"; check "CIDR entry rendered" "$?" 0
has "ip daddr 203.0.113.10 tcp dport 443 accept"; check "hostname resolved (1st addr)" "$?" 0
has "ip daddr 203.0.113.11 tcp dport 443 accept"; check "hostname resolved (2nd addr)" "$?" 0
check "resolved addresses de-duplicated" "$(printf '%s' "$R" | grep -c 'ip daddr 203.0.113.10 tcp dport 443')" 1
has "ip6 daddr 2001:db8::1 udp dport 123 accept"; check "IPv6 entry rendered" "$?" 0
case "$R" in *nowhere*) check "unresolved host writes no rule" 1 0 ;; *) check "unresolved host writes no rule" 0 0 ;; esac
grep -q "could not resolve nowhere.example.net" "$T/err"; check "unresolved host warned" "$?" 0
case "$R" in *"inline comment"*) check "inline comment not emitted" 1 0 ;; *) check "inline comment not emitted" 0 0 ;; esac
has "counter drop"; check "final counter drop" "$?" 0

# --- ICMP / ICMPv6 / DHCPv6: emitted rules (a mock cannot prove they WORK on a kernel) ---
has "icmpv6 type { nd-neighbor-solicit, nd-neighbor-advert, nd-router-solicit,"; check "ICMPv6 neighbour discovery rules emitted" "$?" 0
has "mld2-listener-report"; check "MLDv2 report allowed" "$?" 0
has "packet-too-big"; check "packet-too-big allowed" "$?" 0
has "icmp type { destination-unreachable, time-exceeded, parameter-problem } accept"; check "ICMPv4 error messages allowed" "$?" 0
has "ip6 daddr ff02::1:2 udp sport 546 udp dport 547 accept"; check "DHCPv6 client allowed" "$?" 0
case "$R" in *nd-router-advert*) check "router-advert NOT in output chain (inbound traffic)" 1 0 ;; *) check "router-advert NOT in output chain (inbound traffic)" 0 0 ;; esac
case "$R" in *echo-request*) check "no outbound ping allowed" 1 0 ;; *) check "no outbound ping allowed" 0 0 ;; esac
R2="$(sa_egress_render "$T/allow" 9.9.9.9 none 2>/dev/null)"
case "$R2" in *"192.168.1.0"*|*"fd00:1"*) check "no LAN rule when none" 1 0 ;; *) check "no LAN rule when none" 0 0 ;; esac

# --- validation ---
bad() { printf '%s\n' "$1" > "$T/badallow"; sa_egress_render "$T/badallow" 9.9.9.9 none >/dev/null 2>&1; check "bad allowlist line: $1" "$?" 64; }
bad "1.2.3.4 icmp 80"; bad "1.2.3.4 tcp 0"; bad "1.2.3.4 tcp 70000"; bad "1.2.3.4; rm tcp 80"
bad "bad_host! tcp 443"; bad "1.2.3.4 tcp 443 extra"; bad "1.2.3.4 tcp"; bad "300.1.1.1 tcp 443"
bad "1.2.3.4/33 tcp 443"; bad "1.2.3.999 tcp 443"; bad 'a$(id).example.com tcp 443'
bad "010.0.0.1 tcp 443"; bad "1.02.3.4 tcp 443"
printf '%s\n' "08.0.0.1 tcp 443" > "$T/badallow"; sa_egress_render "$T/badallow" 9.9.9.9 none >/dev/null 2>"$T/err"; check "leading-zero octet rejected" "$?" 64
grep -q "value too great" "$T/err"; check "leading-zero rejection is quiet (no bash octal error)" "$?" 1
for any in "0.0.0.0/0 tcp 443" "::/0 tcp 443" "0::/0 udp 53"; do bad "$any"; done
printf '%s\n' "0.0.0.0/0 tcp 443" > "$T/anyallow"
SA_EGRESS_ALLOW_ANY=1 sa_egress_render "$T/anyallow" 9.9.9.9 none >/dev/null 2>&1; check "/0 allowed only with SA_EGRESS_ALLOW_ANY=1" "$?" 0
sa_egress_render "$T/allow" 9.9.9.9 "0.0.0.0/0" >/dev/null 2>&1; check "LAN /0 refused without override" "$?" 64
sa_egress_render "$T/missing" 9.9.9.9 none >/dev/null 2>&1; check "missing allowlist => 64" "$?" 64
sa_egress_render "$T/allow" "" none >/dev/null 2>&1;        check "no DNS server => 64" "$?" 64
sa_egress_render "$T/allow" "dns.example.com" none >/dev/null 2>&1; check "DNS must be an IP => 64" "$?" 64
sa_egress_render "$T/allow" "9.9.9.0/24" none >/dev/null 2>&1; check "DNS must be one address => 64" "$?" 64
sa_egress_render "$T/allow" 9.9.9.9 "10.0.0.0/99" >/dev/null 2>&1; check "bad LAN range => 64" "$?" 64
sa_egress_render "$T/allow" 9.9.9.9 "192.168.1.0/24,nonsense" >/dev/null 2>&1; check "bad item in LAN list => 64" "$?" 64
printf '%s\n' "1.2.3.4 tcp 443" "garbage line here now" > "$T/half"
out="$(sa_egress_render "$T/half" 9.9.9.9 none 2>/dev/null)"; check "invalid file prints no partial ruleset" "$out" ""

# --- apply: ordering and failure paths ---
: > "$CALLS"; sa_egress_apply "$T/allow" 9.9.9.9 none >/dev/null 2>&1; check "apply ok (no timer)" "$?" 0
[ "$(line_of '^nft -c -f')" -lt "$(line_of '^nft -f')" ]; check "nft -c runs before nft -f" "$?" 0
calls_has systemd-run; check "no revert timer by default" "$?" 1
calls_has "logger -t stackalign-egress -- loaded table=stackalign_egress revert_seconds=0"; check "apply written to syslog" "$?" 0

: > "$CALLS"; export FAKE_NFT_CHECK_RC=1; sa_egress_apply "$T/allow" 9.9.9.9 none 60 >/dev/null 2>&1; check "failed check => rc 1" "$?" 1
calls_has "^nft -f"; check "failed check => nothing loaded" "$?" 1
calls_has systemd-run; check "failed check => no timer scheduled" "$?" 1
unset FAKE_NFT_CHECK_RC

: > "$CALLS"; sa_egress_apply "$T/allow" 9.9.9.9 none 120 >/dev/null 2>&1; check "apply with revert timer ok" "$?" 0
calls_has "systemd-run --quiet --replace --unit=stackalign-egress-revert --on-active=120s .*nft delete table inet stackalign_egress"; check "auto-revert scheduled with --replace" "$?" 0
[ "$(line_of '^systemd-run')" -lt "$(line_of '^nft -f')" ]; check "timer scheduled BEFORE the rules load" "$?" 0
[ "$(line_of 'systemctl stop stackalign-egress-revert.timer')" -lt "$(line_of '^systemd-run')" ]; check "stale timer stopped before re-scheduling" "$?" 0

: > "$CALLS"; export FAKE_SDRUN_RC=1; sa_egress_apply "$T/allow" 9.9.9.9 none 120 >/dev/null 2>"$T/err"; check "timer cannot be scheduled => rc 1" "$?" 1
calls_has "^nft -f"; check "timer failure => rules NEVER loaded" "$?" 1
grep -q "NOTHING was loaded" "$T/err"; check "timer failure message is accurate" "$?" 0
unset FAKE_SDRUN_RC

: > "$CALLS"; export FAKE_NFT_LOAD_RC=1; sa_egress_apply "$T/allow" 9.9.9.9 none 120 >/dev/null 2>&1; check "load failure => rc 1" "$?" 1
[ "$(grep -n 'systemctl stop' "$CALLS" | tail -1 | cut -d: -f1)" -gt "$(line_of '^nft -f')" ]; check "load failure cancels the timer (stop comes AFTER the failed load)" "$?" 0
: > "$CALLS"; export FAKE_STOP_RC=1; sa_egress_apply "$T/allow" 9.9.9.9 none 120 >/dev/null 2>"$T/err"; check "load failure + cancel failure still rc 1" "$?" 1
grep -q "WARNING could not cancel the revert timer" "$T/err"; check "cancel failure is reported" "$?" 0
unset FAKE_NFT_LOAD_RC FAKE_STOP_RC
for s in 5 99999 abc; do sa_egress_apply "$T/allow" 9.9.9.9 none "$s" >/dev/null 2>&1; check "bad revert seconds '$s' => 64" "$?" 64; done

# --- confirm ---
: > "$CALLS"; export FAKE_TIMER_ACTIVE=1; sa_egress_confirm >/dev/null 2>&1; check "confirm with pending timer => 0" "$?" 0
calls_has "systemctl stop stackalign-egress-revert.timer"; check "confirm stops the timer" "$?" 0
export FAKE_STOP_RC=1; sa_egress_confirm >/dev/null 2>"$T/err"; check "cancel fails => rc 1" "$?" 1
grep -q "WILL revert" "$T/err"; check "cancel failure warns the rules will revert" "$?" 0
unset FAKE_STOP_RC FAKE_TIMER_ACTIVE
out="$(sa_egress_confirm 2>&1)"; check "no timer, table loaded => 0" "$?" 0
case "$out" in *"no revert timer was pending"*) check "no-timer message is honest" 0 0 ;; *) check "no-timer message is honest" 1 0 ;; esac
case "$out" in *"auto-revert cancelled"*) check "does not claim a cancellation" 1 0 ;; *) check "does not claim a cancellation" 0 0 ;; esac
FAKE_NFT_LIST_RC=1 sa_egress_confirm >/dev/null 2>&1; check "no timer and table absent => 1" "$?" 1

# --- remove ---
: > "$CALLS"; sa_egress_remove >/dev/null 2>&1; check "remove ok" "$?" 0
calls_has "nft delete table inet stackalign_egress"; check "remove deletes our table only" "$?" 0
: > "$CALLS"; FAKE_NFT_LIST_RC=1 sa_egress_remove >/dev/null 2>&1; check "absent table => 0 (idempotent)" "$?" 0
calls_has "nft delete"; check "absent table => no delete attempted" "$?" 1
FAKE_NFT_DELETE_RC=1 sa_egress_remove >/dev/null 2>"$T/err"; check "real delete failure => 1" "$?" 1
grep -q "may still be active" "$T/err"; check "delete failure says the firewall may still be active" "$?" 0

# --- LAN audit ---
cat > "$T/known" <<'K'
# known devices
AA:BB:CC:DD:EE:01  Studio PC
aa:bb:cc:dd:ee:02  Audio interface
K
cat > "$T/neigh_ok" <<'N'
192.168.1.10 dev eth0 lladdr aa:bb:cc:dd:ee:01 REACHABLE
192.168.1.11 dev eth0 lladdr AA:BB:CC:DD:EE:02 STALE
192.168.1.99 dev eth0  FAILED
fe80::1 dev eth0 lladdr aa:bb:cc:dd:ee:01 router REACHABLE
ff02::1 dev eth0 lladdr 33:33:00:00:00:01 NOARP
224.0.0.251 dev eth0 lladdr 01:00:5e:00:00:fb PERMANENT
N
export FAKE_NEIGH="$T/neigh_ok"; out="$(sa_lan_audit "$T/known" 2>/dev/null)"; check "all known => rc 0" "$?" 0
case "$out" in *"Studio PC"*"Audio interface"*) check "labels shown" 0 0 ;; *) check "labels shown" 1 0 ;; esac
case "$out" in *33:33*|*01:00:5e*) check "multicast MACs skipped" 1 0 ;; *) check "multicast MACs skipped" 0 0 ;; esac
check "IPv6 neighbour with 'router' flag parsed; same MAC listed once" "$(printf '%s\n' "$out" | grep -c 'aa:bb:cc:dd:ee:01')" 1
cat > "$T/neigh_bad" <<'N'
192.168.1.10 dev eth0 lladdr aa:bb:cc:dd:ee:01 REACHABLE
192.168.1.50 dev eth0 lladdr de:ad:be:ef:00:01 REACHABLE
192.168.1.51 dev eth0 lladdr de:ad:be:ef:00:01 STALE
N
export FAKE_NEIGH="$T/neigh_bad"; out="$(sa_lan_audit "$T/known" 2>"$T/err")"; check "unknown device => rc 3" "$?" 3
case "$out" in *"de:ad:be:ef:00:01  UNKNOWN"*) check "unknown flagged" 0 0 ;; *) check "unknown flagged" 1 0 ;; esac
check "same MAC reported once" "$(printf '%s\n' "$out" | grep -c 'de:ad:be:ef:00:01')" 1
check "singular message for one device" "$(cat "$T/err")" "audit: 1 unknown device"
printf '%s\n' "192.168.1.50 dev eth0 lladdr de:ad:be:ef:00:01 REACHABLE" "192.168.1.52 dev eth0 lladdr de:ad:be:ef:00:02 REACHABLE" > "$T/neigh_two"
FAKE_NEIGH="$T/neigh_two" sa_lan_audit "$T/known" >/dev/null 2>"$T/err"; check "two unknown => rc 3" "$?" 3
check "plural message for two devices" "$(cat "$T/err")" "audit: 2 unknown devices"
printf '%s\n' "not-a-mac  Thing" > "$T/known_bad"; sa_lan_audit "$T/known_bad" >/dev/null 2>&1; check "malformed known file => 64" "$?" 64
printf '%s\n' "aa:bb:cc:dd:ee:03  bad;label" > "$T/known_bad2"; sa_lan_audit "$T/known_bad2" >/dev/null 2>&1; check "unsafe label => 64" "$?" 64
sa_lan_audit "$T/none" >/dev/null 2>&1; check "missing known file => 64" "$?" 64
exit "$fail"
