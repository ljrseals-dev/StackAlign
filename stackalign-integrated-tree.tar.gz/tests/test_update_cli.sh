#!/usr/bin/env bash
# SPDX-License-Identifier: MIT
# Author: Lewis James Seals Jr.
# tests/test_update_cli.sh -- CLI-level proof, using the REAL history.sh and service.sh:
# exit codes 0/1/99 reach the shell, config is restored, the RPM is downgraded.
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CLI="$ROOT/bin/stackalign"
W="$(mktemp -d)"; trap 'rm -rf "$W"' EXIT
mkdir -p "$W/bin" "$W/etc-nginx" "$W/cache"

TARGET="nginx-1.31.0-1.el9.x86_64"
OLD="nginx-1.30.6-1.el9.x86_64"
export FAKE_TARGET="$TARGET" STATE="$W/installed" NEWF="$W/new" ETC="$W/etc-nginx" DNF_LOG="$W/dnf.log"
export SA_HISTORY_ROOT="$W/hist" SA_SECRETS_DIR="$W/secrets" SA_RPM_CACHE="$W/cache"
: > "$W/cache/$TARGET.rpm"                 # pre-seeded: no real download

# dnf: install = new binary + new config; downgrade = old binary (new marker removed)
cat > "$W/bin/dnf" <<'F'
#!/usr/bin/env bash
echo "dnf $*" >> "$DNF_LOG"
case "$*" in
  *downgrade*) [ "${DNF_DOWNGRADE_RC:-0}" = 0 ] || exit "$DNF_DOWNGRADE_RC"
               echo "nginx-1.30.6-1.el9.x86_64" > "$STATE"; rm -f "$NEWF"; exit 0 ;;
  *install*)   echo "nginx-1.31.0-1.el9.x86_64" > "$STATE"; : > "$NEWF"; echo new > "$ETC/nginx.conf"; exit 0 ;;
esac
exit 0
F
# rpm: -qp => the package file's NEVRA; -q --qf => installed NEVRA from state
cat > "$W/bin/rpm" <<'F'
#!/usr/bin/env bash
case "$*" in
  *"-qp"*) printf '%s' "$FAKE_TARGET" ;;
  *"--qf"*) cat "$STATE" ;;
esac
exit 0
F
# systemctl: queries ok; reload/restart fail while the NEW binary is installed (unless NEW_OK=1)
cat > "$W/bin/systemctl" <<'F'
#!/usr/bin/env bash
case "$1" in
  is-active) exit 0 ;;
  reload|restart) if [ -e "$NEWF" ] && [ "${NEW_OK:-0}" != 1 ]; then exit 1; fi; exit 0 ;;
esac
exit 0
F
# nginx -t: fails while the NEW binary is installed iff NEW_BROKEN=1
cat > "$W/bin/nginx" <<'F'
#!/usr/bin/env bash
if [ -e "$NEWF" ] && [ "${NEW_BROKEN:-0}" = 1 ]; then exit 1; fi
exit 0
F
chmod +x "$W/bin/"*
export PATH="$W/bin:$PATH"
echo "$OLD" > "$STATE"

pass=0; fail=0
ok()  { pass=$((pass+1)); echo "ok   - $1"; }
bad() { fail=$((fail+1)); echo "FAIL - $1"; [ -s "$DNF_LOG" ] && sed 's/^/       dnf: /' "$DNF_LOG"; }
reset() { : > "$DNF_LOG"; echo "$OLD" > "$STATE"; rm -f "$NEWF"; echo old > "$ETC/nginx.conf"; rm -rf "$W/hist"
          unset DNF_DOWNGRADE_RC NEW_OK NEW_BROKEN; }
apply() { OUT=$("$CLI" update apply nginx "$TARGET" nginx "$ETC" --apply 2>&1); RC=$?; }
logged() { grep -q -- "$1" "$DNF_LOG"; }

reset; export NEW_OK=1; apply
[ $RC -eq 0 ] && ok "healthy update => exit 0" || bad "healthy update => exit 0 (rc=$RC) $OUT"
! logged "downgrade" && ok "no downgrade on success" || bad "no downgrade on success"
[ "$(cat "$ETC/nginx.conf")" = new ] && ok "new config kept on success" || bad "new config kept on success"

reset; apply
[ $RC -eq 1 ] && ok "reload fails => rolled back => exit 1" || bad "reload fails => exit 1 (rc=$RC) $OUT"
logged "dnf -y install" && logged "dnf -y downgrade $OLD" && ok "install then downgrade to old NEVRA" || bad "install then downgrade to old NEVRA"
[ "$(cat "$ETC/nginx.conf")" = old ] && ok "config restored from snapshot" || bad "config restored from snapshot"
[ "$(cat "$STATE")" = "$OLD" ] && ok "package back at old NEVRA" || bad "package back at old NEVRA"

reset; export NEW_BROKEN=1; apply
[ $RC -eq 1 ] && ok "new binary broken (reload_safe exit 99 caught) => recovered => exit 1" || bad "broken new binary => exit 1 (rc=$RC) $OUT"
logged "dnf -y downgrade $OLD" && ok "downgrade still attempted after reload_safe exit 99" || bad "downgrade still attempted after exit 99"
[ "$(cat "$ETC/nginx.conf")" = old ] && ok "config restored (broken-binary case)" || bad "config restored (broken-binary case)"

reset; export DNF_DOWNGRADE_RC=1; apply
[ $RC -eq 99 ] && ok "downgrade fails => exit 99" || bad "downgrade fails => exit 99 (rc=$RC) $OUT"

reset; OUT=$("$CLI" update apply nginx "$TARGET" nginx "$ETC" 2>&1); RC=$?
{ [ $RC -eq 0 ] && [[ $OUT == *"plan:"* ]] && [[ $OUT == *"--apply"* ]]; } && ok "no --apply => plan only, exit 0" || bad "plan mode (rc=$RC)"
[ ! -s "$DNF_LOG" ] && [ "$(cat "$ETC/nginx.conf")" = old ] && ok "plan mode changes nothing" || bad "plan mode changes nothing"

reset; OUT=$("$CLI" --plan update apply nginx "$TARGET" nginx "$ETC" --apply 2>&1); RC=$?
[ $RC -eq 64 ] && ok "--plan with --apply => 64" || bad "--plan with --apply => 64 (rc=$RC)"

reset; OUT=$("$CLI" plan update apply nginx "$TARGET" nginx "$ETC" 2>&1); RC=$?
{ [ $RC -eq 0 ] && [ ! -s "$DNF_LOG" ]; } && ok "plan <cmd> alias is read-only" || bad "plan alias (rc=$RC)"

reset; OUT=$("$CLI" update apply nginx "$TARGET" --apply 2>&1); RC=$?
{ [ $RC -eq 64 ] && [ ! -s "$DNF_LOG" ]; } && ok "bad arg count => 64, no dnf" || bad "bad arg count (rc=$RC)"

reset; OUT=$("$CLI" update apply nginx "$TARGET" apache "$ETC" --apply 2>&1); RC=$?
{ [ $RC -eq 1 ] && [ ! -s "$DNF_LOG" ]; } && ok "unknown service refused before any change" || bad "unknown service (rc=$RC)"

reset; OUT=$("$CLI" update check 2>&1); RC=$?
{ [ $RC -eq 2 ] && [[ $OUT == *"not implemented"* ]]; } && ok "update check is an honest stub (rc 2)" || bad "update check stub (rc=$RC)"

reset; OUT=$("$CLI" update bogus 2>&1); RC=$?
[ $RC -eq 64 ] && ok "unknown update subcommand => 64" || bad "unknown update subcommand (rc=$RC)"

echo "passed=$pass failed=$fail"; [ $fail -eq 0 ]
