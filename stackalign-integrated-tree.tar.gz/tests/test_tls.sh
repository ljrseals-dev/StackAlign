#!/usr/bin/env bash
# SPDX-License-Identifier: MIT
# Author: Lewis James Seals Jr.
# tests/test_tls.sh
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
mkdir -p "$T/bin"; : > "$T/calls"
export CALLS="$T/calls" PATH="$T/bin:$PATH"
fail=0
check() { if [ "$2" = "$3" ]; then echo "ok   $1"; else echo "FAIL $1 (got '$2' want '$3')"; fail=1; fi; }
mkfake() { printf "%s
" "#!/usr/bin/env bash" "$2" > "$T/bin/$1"; chmod +x "$T/bin/$1"; }
mkfake systemctl 'echo "systemctl $*" >> "$CALLS"; case "$1" in is-active) u="${@: -1}"; case " ${FAKE_ACTIVE:-} " in *" $u "*) exit 0 ;; esac; exit 3 ;; esac; exit 0'
mkfake crontab 'printf "%s\n" "${FAKE_CRON:-}"'
mkfake lego 'echo "lego $*" >> "$CALLS"; p=""; d=""; while [ $# -gt 0 ]; do case "$1" in --path) p="$2";; --domains) d="$2";; esac; shift; done; b="${d/#\*/_}"; mkdir -p "$p/certificates"; echo CRT > "$p/certificates/$b.crt"; echo KEY > "$p/certificates/$b.key"'
mkfake certbot 'echo "certbot $*" >> "$CALLS"; c=""; n=""; while [ $# -gt 0 ]; do case "$1" in --config-dir) c="$2";; --cert-name) n="$2";; esac; shift; done; mkdir -p "$c/live/$n"; echo CRT > "$c/live/$n/fullchain.pem"; echo KEY > "$c/live/$n/privkey.pem"'
export SA_CERT_ROOT="$T/certs"; mkdir -p "$T/web"
sa_history_snapshot() { echo "snapshot $*" >> "$CALLS"; echo SNAP7; }
RELOAD_RC=0
sa_service_reload_safe() { echo "reload $*" >> "$CALLS"; return "$RELOAD_RC"; }
. "$ROOT/lib/tls.sh"
D=example.com; E=ops@example.com

sa_tls_issue $D lego letsencrypt http-01 "$T/web" $E nginx >/dev/null 2>&1; check "lego http-01 ok" "$?" 0
check "fullchain deployed" "$(cat "$SA_CERT_ROOT/$D/fullchain.pem")" CRT
check "privkey mode 600" "$(stat -c %a "$SA_CERT_ROOT/$D/privkey.pem")" 600
check ".client recorded" "$(cat "$SA_CERT_ROOT/$D/.client")" lego
grep -q "reload nginx SNAP7" "$CALLS"; check "reload got service+snapshot" "$?" 0
grep -q "snapshot $SA_CERT_ROOT/$D pre-tls-$D" "$CALLS"; check "snapshot before deploy" "$?" 0
sa_tls_issue $D certbot letsencrypt http-01 "$T/web" $E nginx >/dev/null 2>&1; check "client switch refused" "$?" 1

sa_tls_issue "*.example.org" lego letsencrypt dns-01 cloudflare $E nginx >/dev/null 2>&1; check "wildcard dns-01 ok" "$?" 0
check "wildcard lineage dir" "$(cat "$SA_CERT_ROOT/_wildcard_.example.org/fullchain.pem")" CRT
grep -q -- "--dns cloudflare" "$CALLS"; check "dns provider passed" "$?" 0

sa_tls_issue "a;b.com" lego letsencrypt http-01 "$T/web" $E nginx >/dev/null 2>&1; check "bad domain" "$?" 64
sa_tls_issue $D lego letsencrypt http-01 "$T/web" "not-an-email" nginx >/dev/null 2>&1; check "bad email" "$?" 64
sa_tls_issue d2.example.com certbot letsencrypt dns-01 cloudflare $E nginx >/dev/null 2>&1; check "dns-01 needs lego" "$?" 64
sa_tls_issue d2.example.com lego letsencrypt http-01 relative/dir $E nginx >/dev/null 2>&1; check "relative webroot" "$?" 64
sa_tls_issue d2.example.com lego bogusca http-01 "$T/web" $E nginx >/dev/null 2>&1; check "bad ca" "$?" 64

sa_tls_issue z.example.com lego zerossl http-01 "$T/web" $E nginx >/dev/null 2>&1; check "zerossl needs EAB" "$?" 1
export SA_TLS_EAB_KID=kid1 SA_TLS_EAB_HMAC=hmac1
sa_tls_issue z.example.com lego zerossl http-01 "$T/web" $E nginx >/dev/null 2>&1; check "zerossl with EAB ok" "$?" 0
grep -q -- "--eab --kid kid1 --hmac hmac1" "$CALLS"; check "EAB flags passed" "$?" 0
sa_tls_issue c.example.com certbot letsencrypt http-01 "$T/web" $E nginx >/dev/null 2>&1; check "certbot ok" "$?" 0
check "certbot cert deployed" "$(cat "$SA_CERT_ROOT/c.example.com/privkey.pem")" KEY

RELOAD_RC=1; sa_tls_issue r.example.com lego letsencrypt http-01 "$T/web" $E nginx >/dev/null 2>&1; check "reload failure => rc 1" "$?" 1
RELOAD_RC=0

unset FAKE_ACTIVE FAKE_CRON
sa_tls_preflight >/dev/null; check "preflight clean" "$?" 0
FAKE_ACTIVE="certbot.timer" sa_tls_preflight >/dev/null; check "preflight sees certbot.timer" "$?" 2
FAKE_CRON="0 0 * * * /root/.acme.sh/acme.sh --cron" sa_tls_preflight >/dev/null; check "preflight sees acme.sh cron" "$?" 2

: > "$CALLS"; FAKE_ACTIVE="certbot.timer" sa_tls_enable_renewal_timer >/dev/null 2>&1; check "timer refused while certbot.timer active" "$?" 2
grep -q "enable --now" "$CALLS"; check "timer not enabled" "$?" 1
FAKE_ACTIVE="certbot.timer" SA_TLS_ALLOW_UPSTREAM=1 sa_tls_enable_renewal_timer >/dev/null 2>&1; check "override allows timer" "$?" 0
grep -q "enable --now stackalign-renew.timer" "$CALLS"; check "timer enabled with override" "$?" 0
exit "$fail"
