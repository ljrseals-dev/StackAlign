#!/usr/bin/env bash
# SPDX-License-Identifier: MIT
# Author: Lewis James Seals Jr.
# tests/test_firewall.sh
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
mkdir -p "$T/bin"; : > "$T/calls"
export CALLS="$T/calls" PATH="$T/bin:$PATH"
fail=0
check() { if [ "$2" = "$3" ]; then echo "ok   $1"; else echo "FAIL $1 (got '$2' want '$3')"; fail=1; fi; }
mkfake() { printf "%s
" "#!/usr/bin/env bash" "$2" > "$T/bin/$1"; chmod +x "$T/bin/$1"; }
mkfake systemctl 'u="${@: -1}"; case " ${FAKE_ACTIVE:-} " in *" $u "*) exit 0 ;; esac; exit 3'
mkfake nft 'echo "nft $*" >> "$CALLS"; case "$1" in -c) exit "${FAKE_NFT_CHECK_RC:-0}" ;; esac; exit 0'
mkfake dnf 'echo "dnf $*" >> "$CALLS"; exit 0'
. "$ROOT/lib/firewall.sh"

sa_fw_validate nftables crowdsec 22 on;   check "validate ok" "$?" 0
sa_fw_validate iptables crowdsec 22 on 2>/dev/null; check "bad backend" "$?" 64
sa_fw_validate nftables csf 22 on 2>/dev/null;      check "bad intrusion" "$?" 64
sa_fw_validate nftables none 0 on 2>/dev/null;      check "port 0 rejected" "$?" 64
sa_fw_validate nftables none 70000 on 2>/dev/null;  check "port 70000 rejected" "$?" 64
sa_fw_validate nftables none "22;x" on 2>/dev/null; check "port injection rejected" "$?" 64
sa_fw_validate nftables none 22 maybe 2>/dev/null;  check "bad http3" "$?" 64

sa_fw_refuse_ftp vsftpd 2>/dev/null;   check "vsftpd refused" "$?" 3
sa_fw_refuse_ftp Pure-FTPd 2>/dev/null; check "pure-ftpd refused (case)" "$?" 3
sa_fw_refuse_ftp nginx;                check "nginx allowed" "$?" 0

export FAKE_ACTIVE="firewalld";            check "detect firewalld" "$(sa_fw_detect_backend 2>/dev/null)" firewalld
export FAKE_ACTIVE="nftables";             check "detect nftables" "$(sa_fw_detect_backend 2>/dev/null)" nftables
export FAKE_ACTIVE="firewalld nftables";   sa_fw_detect_backend >/dev/null 2>&1; check "mixed refused" "$?" 1

r="$(sa_fw_render_nft 2222 on)"
case "$r" in *"tcp dport 2222 accept"*) check "ssh port rendered" 0 0 ;; *) check "ssh port rendered" 1 0 ;; esac
case "$r" in *"udp dport 443 accept"*) check "udp 443 when http3 on" 0 0 ;; *) check "udp 443 when http3 on" 1 0 ;; esac
r="$(sa_fw_render_nft 22 off)"
case "$r" in *udp*) check "no udp when http3 off" 1 0 ;; *) check "no udp when http3 off" 0 0 ;; esac
case "$r" in *"policy drop"*"ct state established"*) check "drop policy + established" 0 0 ;; *) check "drop policy + established" 1 0 ;; esac

: > "$CALLS"; sa_fw_apply_nft 22 on >/dev/null 2>&1; check "apply ok" "$?" 0
grep -q "^nft -c -f" "$CALLS"; check "checked first" "$?" 0
grep -q "^nft -f" "$CALLS"; check "then loaded" "$?" 0
: > "$CALLS"; export FAKE_NFT_CHECK_RC=1
sa_fw_apply_nft 22 on >/dev/null 2>&1; check "failed check => rc 1" "$?" 1
grep -q "^nft -f" "$CALLS"; check "failed check => nothing loaded" "$?" 1
unset FAKE_NFT_CHECK_RC

: > "$CALLS"; sa_fw_install_intrusion crowdsec; grep -q "dnf -y install -- crowdsec crowdsec-firewall-bouncer-nftables" "$CALLS"; check "crowdsec via dnf" "$?" 0
: > "$CALLS"; sa_fw_install_intrusion fail2ban;  grep -q "dnf -y install -- fail2ban" "$CALLS"; check "fail2ban via dnf" "$?" 0
: > "$CALLS"; sa_fw_install_intrusion none;      check "none => no-op" "$(wc -c < "$CALLS" | tr -d ' ')" 0
sa_fw_install_intrusion csf 2>/dev/null; check "csf rejected" "$?" 64
exit "$fail"
