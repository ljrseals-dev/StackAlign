#!/usr/bin/env bash
# SPDX-License-Identifier: MIT
# Author: Lewis James Seals Jr.
# tests/test_extensions.sh
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
mkdir -p "$T/bin"; : > "$T/calls"
export CALLS="$T/calls" PATH="$T/bin:$PATH"
fail=0
check() { if [ "$2" = "$3" ]; then echo "ok   $1"; else echo "FAIL $1 (got '$2' want '$3')"; fail=1; fi; }
mkfake() { printf "%s
" "#!/usr/bin/env bash" "$2" > "$T/bin/$1"; chmod +x "$T/bin/$1"; }
mkfake dnf 'echo "dnf $*" >> "$CALLS"; if [ "$1" = -q ] && [ "$2" = list ]; then case " ${FAKE_AVAIL:-} " in *" ${@: -1} "*) exit 0 ;; esac; exit 1; fi; exit 0'
. "$ROOT/lib/extensions.sh"
export FAKE_AVAIL="php-pecl-redis php-pecl-imagick"

sa_ext_install "redis,imagick" >/dev/null 2>&1; check "allowed + available => ok" "$?" 0
grep -q "dnf -y install -- php-pecl-redis php-pecl-imagick" "$CALLS"; check "single install call" "$?" 0
: > "$CALLS"; sa_ext_install "redis,evil" >/dev/null 2>&1; check "unknown ext rejected" "$?" 64
grep -q "install" "$CALLS"; check "nothing installed on reject" "$?" 1
: > "$CALLS"; sa_ext_install "ffmpeg" >/dev/null 2>&1; check "unavailable pkg refused" "$?" 1
grep -q "dnf -y install" "$CALLS"; check "no install when unavailable" "$?" 1
: > "$CALLS"; sa_ext_install "" ; check "empty list is no-op" "$?" 0
exit "$fail"
