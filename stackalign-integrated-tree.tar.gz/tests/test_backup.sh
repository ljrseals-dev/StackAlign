#!/usr/bin/env bash
# SPDX-License-Identifier: MIT
# Author: Lewis James Seals Jr.
# tests/test_backup.sh
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
mkdir -p "$T/bin"; : > "$T/calls"
export CALLS="$T/calls" PATH="$T/bin:$PATH"
fail=0
check() { if [ "$2" = "$3" ]; then echo "ok   $1"; else echo "FAIL $1 (got '$2' want '$3')"; fail=1; fi; }
mkfake() { printf "%s
" "#!/usr/bin/env bash" "$2" > "$T/bin/$1"; chmod +x "$T/bin/$1"; }
mkfake mysqldump 'echo "mysqldump $*" >> "$CALLS"; [ "${FAKE_DUMP_FAIL:-0}" = 1 ] && exit 1; echo "SELECT 1;"'
mkfake mariabackup 'echo "mariabackup $*" >> "$CALLS"; for a in "$@"; do case "$a" in --target-dir=*) mkdir -p "${a#--target-dir=}";; esac; done'
mkfake rclone 'echo "rclone $*" >> "$CALLS"'
printf '[client]\nuser=backup\n' > "$T/my.cnf"; export SA_MYSQL_DEFAULTS_FILE="$T/my.cnf"
. "$ROOT/lib/backup.sh"

f="$(sa_backup_dump "$T/out" 2>/dev/null)"; check "dump ok" "$?" 0
check "dump content" "$(gunzip -c "$f")" "SELECT 1;"
check "dump mode 600" "$(stat -c %a "$f")" 600
check "no .part left" "$(ls "$T/out" | grep -c '\.part$')" 0
grep -q -- "--defaults-extra-file=$T/my.cnf" "$CALLS"; check "creds via defaults file" "$?" 0
if grep -Eq -- '--password|-p[A-Za-z0-9]' "$CALLS"; then check "no password on argv" 1 0; else check "no password on argv" 0 0; fi

rm -rf "$T/out2"; FAKE_DUMP_FAIL=1 sa_backup_dump "$T/out2" >/dev/null 2>&1; check "dump failure => rc 1" "$?" 1
check "failed dump leaves no file" "$(ls "$T/out2" 2>/dev/null | wc -l | tr -d ' ')" 0
sa_backup_dump "../x" >/dev/null 2>&1; check "bad dest dir" "$?" 64
( unset SA_MYSQL_DEFAULTS_FILE; sa_backup_dump "$T/out3" >/dev/null 2>&1 ); check "missing defaults file" "$?" 64

: > "$CALLS"; sa_backup_physical "$T/phys" >/dev/null 2>&1; check "physical ok" "$?" 0
grep -q -- "--backup --target-dir=$T/phys" "$CALLS"; check "backup called" "$?" 0
grep -q -- "--prepare --target-dir=$T/phys" "$CALLS"; check "prepare called" "$?" 0
sa_backup_physical "$T/phys" >/dev/null 2>&1; check "existing target refused" "$?" 1

mkdir -p "$T/src"
sa_backup_rclone "$T/src" "b2remote:bucket/path" >/dev/null 2>&1; check "rclone ok" "$?" 0
grep -q "rclone copy -- $T/src b2remote:bucket/path" "$CALLS"; check "rclone args" "$?" 0
sa_backup_rclone "$T/src" 'x;rm -rf /' >/dev/null 2>&1; check "bad remote rejected" "$?" 64
sa_backup_rclone "$T/src" 'r:../etc' >/dev/null 2>&1; check "remote traversal rejected" "$?" 64
sa_backup_rclone "relative" "r:p" >/dev/null 2>&1; check "bad source rejected" "$?" 64
exit "$fail"
