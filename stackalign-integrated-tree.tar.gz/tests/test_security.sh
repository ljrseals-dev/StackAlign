#!/usr/bin/env bash
# SPDX-License-Identifier: MIT
# Author: Lewis James Seals Jr.
# tests/test_security.sh
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
mkdir -p "$T/bin"; : > "$T/calls"
export CALLS="$T/calls" PATH="$T/bin:$PATH"
fail=0
check() { if [ "$2" = "$3" ]; then echo "ok   $1"; else echo "FAIL $1 (got '$2' want '$3')"; fail=1; fi; }
mkfake() { printf "%s
" "#!/usr/bin/env bash" "$2" > "$T/bin/$1"; chmod +x "$T/bin/$1"; }
mkfake clamscan 'echo "clamscan $*" >> "$CALLS"; printf "%s" "${FAKE_OUT:-}"; exit "${FAKE_RC:-0}"'
export SA_AUDIT_QUEUE="$T/audit/queue.jsonl"; mkdir -p "$T/www"
. "$ROOT/lib/security.sh"

FAKE_OUT=$'/var/www/a/evil.php: Eicar-Test-Signature FOUND\n' FAKE_RC=1 sa_security_scan "$T/www" >/dev/null; check "findings => rc 0 (advisory)" "$?" 0
check "one JSON line queued" "$(wc -l < "$SA_AUDIT_QUEUE" | tr -d ' ')" 1
grep -q '"path":"/var/www/a/evil.php"' "$SA_AUDIT_QUEUE"; check "path recorded" "$?" 0
grep -q '"signature":"Eicar-Test-Signature"' "$SA_AUDIT_QUEUE"; check "signature recorded" "$?" 0
grep -q '"action":"none"' "$SA_AUDIT_QUEUE"; check "action none" "$?" 0
if grep -Eq -- '--remove|--move|--copy' "$CALLS"; then check "no quarantine/delete flags" 1 0; else check "no quarantine/delete flags" 0 0; fi

: > "$SA_AUDIT_QUEUE"
FAKE_OUT=$'/var/www/a"b/x.php: Sig.One FOUND\n' FAKE_RC=1 sa_security_scan "$T/www" >/dev/null
grep -q '/var/www/a\\"b/x.php' "$SA_AUDIT_QUEUE"; check "quote escaped in JSON" "$?" 0

: > "$SA_AUDIT_QUEUE"; out="$(FAKE_OUT="" FAKE_RC=0 sa_security_scan "$T/www")"
case "$out" in *"0 finding(s)"*) check "clean scan reports 0" 0 0 ;; *) check "clean scan reports 0" 1 0 ;; esac
check "clean scan queues nothing" "$(wc -c < "$SA_AUDIT_QUEUE" | tr -d ' ')" 0

FAKE_RC=2 sa_security_scan "$T/www" >/dev/null 2>&1; check "scanner error => rc 2" "$?" 2
sa_security_scan "relative/dir" >/dev/null 2>&1; check "relative docroot rejected" "$?" 64
sa_security_scan "$T/nope" >/dev/null 2>&1; check "missing docroot rejected" "$?" 64
sa_security_scan >/dev/null 2>&1; check "no args => 64" "$?" 64
exit "$fail"
